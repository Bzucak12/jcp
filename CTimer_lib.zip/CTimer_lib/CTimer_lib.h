#ifndef CTIMER_LIB
#define CTIMER_LIB

#include <Arduino.h>

class CTimer {
  private:
    unsigned long m_startTime;
    unsigned long m_time;

    bool Check() {
      if (!m_time) {
        return true;
      }

      if (!m_startTime) {
        m_startTime = millis();
      }

      unsigned long now = millis();

      if ((now - m_startTime) >= m_time) {
        m_startTime = now;
        return true;
      }

      return false;
    }

  public:
    explicit CTimer() : m_startTime(0), m_time(0) {}
    explicit CTimer(long t) : m_startTime(0), m_time((unsigned long)t) {}

    operator bool () { return Check(); }
    operator ! () { return !m_time; }
    operator long () { return (long)m_time; }
    operator int () { return (int)m_time; }
    operator unsigned long () { return m_time; }
    operator unsigned int () { return (unsigned int)m_time; }
    operator = (long time) { m_startTime = 0; m_time = time; return m_time; }
    operator == (long time) { return m_time == time; }
    operator != (long time) { return m_time != time; }
    operator > (long time) { return m_time > time; }
    operator < (long time) { return m_time < time; }
    operator >= (long time) { return m_time >= time; }
    operator <= (long time) { return m_time <= time; }
    operator += (long time) { return m_time += time; }
    operator -= (long time) { return m_time -= time; }
    operator ++ (int) { return m_time++; }
    operator -- (int) { return m_time--; }
    operator ++ () { return ++m_time; }
    operator -- () { return --m_time; }
    operator *= (long time) { return m_time *= time; }
    operator /= (long time) { return m_time /= time; }
    operator + (long time) { return m_time + time; }
    operator - (long time) { return m_time - time; }
    operator * (long time) { return m_time * time; }
    operator / (long time) { return m_time / time; }
    operator && (bool b) { return Check() && b; }
    operator || (bool b) { return Check() || b; }
    operator ~ () { return ~m_time; }
    operator & (long time) { return m_time & time; }
    operator | (long time) { return m_time | time; }
    operator ^ (long time) { return m_time ^ time; }
    operator %= (long time) { return m_time %= time; }
    operator % (long time) { return m_time % time; }
    operator &= (long time) { return m_time &= time; }
    operator |= (long time) { return m_time |= time; }
    operator ^= (long time) { return m_time ^= time; }
    operator << (long time) { return m_time << time; }
    operator <<= (long time) { return m_time <<= time; }
    operator >> (long time) { return m_time >> time; }
    operator >>= (long time) { return m_time >>= time; }
};

#endif